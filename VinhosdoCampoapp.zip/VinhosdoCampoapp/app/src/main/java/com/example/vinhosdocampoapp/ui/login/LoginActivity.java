package com.example.vinhosdocampoapp.ui.login;

import android.animation.ObjectAnimator;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;

import com.example.vinhosdocampoapp.R; // Importa a classe R gerada
import com.example.vinhosdocampoapp.ui.home.MainActivity; // Tela principal

public class LoginActivity extends AppCompatActivity {

    private EditText emailEditText;
    private EditText passwordEditText;
    private Button loginButton;
    private ImageView logoImageView;
    private ProgressBar loadingProgressBar;

    private LoginViewModel loginViewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Inicializa as Views
        emailEditText = findViewById(R.id.email_edit_text);
        passwordEditText = findViewById(R.id.password_edit_text);
        loginButton = findViewById(R.id.login_button);
        logoImageView = findViewById(R.id.logo_vinhos_do_campo);
        loadingProgressBar = findViewById(R.id.loading_progress_bar);

        // Inicializa o ViewModel
        loginViewModel = new ViewModelProvider(this).get(LoginViewModel.class);

        // Animação de Fade In para o logo
        logoImageView.setAlpha(0f); // Começa invisível
        logoImageView.animate()
                .alpha(1f) // Fica totalmente visível
                .setDuration(1500) // 1.5 segundos
                .start();

        // Observa o LiveData do ViewModel para o estado de login
        loginViewModel.getLoginResult().observe(this, loginResult -> {
            if (loginResult != null) {
                loadingProgressBar.setVisibility(View.GONE); // Esconde o spinner

                if (loginResult) { // Login bem-sucedido
                    Toast.makeText(LoginActivity.this, "Login bem-sucedido!", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                    startActivity(intent);
                    finish(); // Fecha a tela de login
                } else { // Login falhou
                    Toast.makeText(LoginActivity.this, "Credenciais inválidas.", Toast.LENGTH_LONG).show();
                }
            }
        });

        // Observa o LiveData do ViewModel para o estado de carregamento
        loginViewModel.getIsLoading().observe(this, isLoading -> {
            if (isLoading) {
                loadingProgressBar.setVisibility(View.VISIBLE);
                loginButton.setEnabled(false); // Desabilita o botão enquanto carrega
            } else {
                loadingProgressBar.setVisibility(View.GONE);
                loginButton.setEnabled(true); // Habilita o botão
            }
        });


        // Listener para o botão de Login
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = emailEditText.getText().toString().trim();
                String password = passwordEditText.getText().toString().trim();

                if (email.isEmpty() || password.isEmpty()) {
                    Toast.makeText(LoginActivity.this, "Por favor, preencha todos os campos.", Toast.LENGTH_SHORT).show();
                    return;
                }
                loginViewModel.login(email, password); // Chama o método de login no ViewModel
            }
        });
    }
}