package com.example.vinhosdocampoapp.ui.login;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.example.vinhosdocampoapp.data.repository.AuthRepository; // Importa o repositório

public class LoginViewModel extends ViewModel {

    private MutableLiveData<Boolean> loginResult = new MutableLiveData<>();
    private MutableLiveData<Boolean> isLoading = new MutableLiveData<>();
    private AuthRepository authRepository;

    public LoginViewModel() {
        authRepository = new AuthRepository(); // Instancia o repositório
    }

    public LiveData<Boolean> getLoginResult() {
        return loginResult;
    }

    public LiveData<Boolean> getIsLoading() {
        return isLoading;
    }

    public void login(String email, String password) {
        isLoading.setValue(true); // Indica que o login está em andamento

        // Chama o método de login do repositório
        authRepository.login(email, password, new AuthRepository.LoginCallback() {
            @Override
            public void onSuccess(String token) {
                loginResult.postValue(true); // Login bem-sucedido
                isLoading.postValue(false);  // Esconde o loading
            }

            @Override
            public void onFailure(String errorMessage) {
                loginResult.postValue(false); // Login falhou
                isLoading.postValue(false);   // Esconde o loading
            }
        });
    }
}