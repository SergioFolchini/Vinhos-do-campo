package com.example.vinhosdocampoapp.data.database.dao;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import com.example.vinhosdocampoapp.data.database.entity.Cliente;

import java.util.List;

@Dao
public interface ClienteDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insert(Cliente cliente);

    @Query("SELECT * FROM clientes ORDER BY nome ASC")
    LiveData<List<Cliente>> getAllClientes();

    @Query("SELECT * FROM clientes WHERE representanteId = :representanteId ORDER BY nome ASC")
    LiveData<List<Cliente>> getClientesByRepresentante(int representanteId);
}