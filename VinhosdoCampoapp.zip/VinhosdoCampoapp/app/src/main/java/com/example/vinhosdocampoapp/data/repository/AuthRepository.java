package com.example.vinhosdocampoapp.data.repository;

import android.os.Handler;
import android.os.Looper;

public class AuthRepository {

    // Interface de callback para retornar o resultado do login
    public interface LoginCallback {
        void onSuccess(String token);
        void onFailure(String errorMessage);
    }

    public void login(String email, String password, LoginCallback callback) {
        // Simulação de chamada de API com um atraso de 2 segundos
        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
            @Override
            public void run() {
                if (email.equals("admin@vinhos.com") && password.equals("123")) {
                    // Simula um token de autenticação
                    callback.onSuccess("fake-jwt-token-12345");
                } else {
                    callback.onFailure("Credenciais inválidas");
                }
            }
        }, 2000); // 2 segundos de atraso
    }
}