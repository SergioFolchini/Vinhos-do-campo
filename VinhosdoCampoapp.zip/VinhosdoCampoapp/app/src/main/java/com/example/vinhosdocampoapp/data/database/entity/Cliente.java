package com.example.vinhosdocampoapp.data.database.entity;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "clientes")
public class Cliente {
    @PrimaryKey(autoGenerate = true)
    public int id;
    public String nome;
    public String cnpjCpf;
    public String endereco;
    public String responsavel;
    public String contatos;
    public double latitude;
    public double longitude;
    public int representanteId; // Quem cadastrou/gerencia este cliente

    public Cliente() {}

    public Cliente(String nome, String cnpjCpf, String endereco, String responsavel, String contatos, double latitude, double longitude, int representanteId) {
        this.nome = nome;
        this.cnpjCpf = cnpjCpf;
        this.endereco = endereco;
        this.responsavel = responsavel;
        this.contatos = contatos;
        this.latitude = latitude;
        this.longitude = longitude;
        this.representanteId = representanteId;
    }

    // Getters e Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }
    public String getCnpjCpf() { return cnpjCpf; }
    public void setCnpjCpf(String cnpjCpf) { this.cnpjCpf = cnpjCpf; }
    public String getEndereco() { return endereco; }
    public void setEndereco(String endereco) { this.endereco = endereco; }
    public String getResponsavel() { return responsavel; }
    public void setResponsavel(String responsavel) { this.responsavel = responsavel; }
    public String getContatos() { return contatos; }
    public void setContatos(String contatos) { this.contatos = contatos; }
    public double getLatitude() { return latitude; }
    public void setLatitude(double latitude) { this.latitude = latitude; }
    public double getLongitude() { return longitude; }
    public void setLongitude(double longitude) { this.longitude = longitude; }
    public int getRepresentanteId() { return representanteId; }
    public void setRepresentanteId(int representanteId) { this.representanteId = representanteId; }
}
