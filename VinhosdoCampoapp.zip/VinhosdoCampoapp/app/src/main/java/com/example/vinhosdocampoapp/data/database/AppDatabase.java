package com.example.vinhosdocampoapp.data.database;

import android.content.Context;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

import com.example.vinhosdocampoapp.data.database.dao.ClienteDao;
import com.example.vinhosdocampoapp.data.database.dao.VinhoDao;
import com.example.vinhosdocampoapp.data.database.entity.Cliente;
import com.example.vinhosdocampoapp.data.database.entity.Vinho;

@Database(entities = {Vinho.class, Cliente.class}, version = 1, exportSchema = false)
public abstract class AppDatabase extends RoomDatabase {

    public abstract VinhoDao vinhoDao();
    public abstract ClienteDao clienteDao();

    private static volatile AppDatabase INSTANCE;

    public static AppDatabase getDatabase(final Context context) {
        if (INSTANCE == null) {
            synchronized (AppDatabase.class) {
                if (INSTANCE == null) {
                    INSTANCE = Room.databaseBuilder(context.getApplicationContext(),
                                    AppDatabase.class, "vinhos_db")
                            .build();
                }
            }
        }
        return INSTANCE;
    }
}