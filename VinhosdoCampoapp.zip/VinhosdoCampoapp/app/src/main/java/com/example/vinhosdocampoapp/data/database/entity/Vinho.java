package com.example.vinhosdocampoapp.data.database.entity;


import androidx.room.Entity;
import androidx.room.PrimaryKey;
@Entity(tableName = "vinhos")
public class Vinho {
    @PrimaryKey(autoGenerate = true)
    public int id;
    public String nome;
    public int safra;
    public String tipo;
    public String notasDegustacao;
    public String harmonizacoes;
    public String imagemUrl;
    public double preco;

    // Construtor vazio é necessário para Room em alguns casos
    public Vinho() {}

    // Construtor completo (opcional, mas útil)
    public Vinho(String nome, int safra, String tipo, String notasDegustacao, String harmonizacoes, String imagemUrl, double preco) {
        this.nome = nome;
        this.safra = safra;
        this.tipo = tipo;
        this.notasDegustacao = notasDegustacao;
        this.harmonizacoes = harmonizacoes;
        this.imagemUrl = imagemUrl;
        this.preco = preco;
    }

    // Getters e Setters (pode gerar automaticamente no Android Studio: Alt+Insert ou Code -> Generate)
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }
    public int getSafra() { return safra; }
    public void setSafra(int safra) { this.safra = safra; }
    public String getTipo() { return tipo; }
    public void setTipo(String tipo) { this.tipo = tipo; }
    public String getNotasDegustacao() { return notasDegustacao; }
    public void setNotasDegustacao(String notasDegustacao) { this.notasDegustacao = notasDegustacao; }
    public String getHarmonizacoes() { return harmonizacoes; }
    public void setHarmonizacoes(String harmonizacoes) { this.harmonizacoes = harmonizacoes; }
    public String getImagemUrl() { return imagemUrl; }
    public void setImagemUrl(String imagemUrl) { this.imagemUrl = imagemUrl; }
    public double getPreco() { return preco; }
    public void setPreco(double preco) { this.preco = preco; }
}