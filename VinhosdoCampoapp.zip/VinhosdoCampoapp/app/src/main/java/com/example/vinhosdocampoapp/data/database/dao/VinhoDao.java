package com.example.vinhosdocampoapp.data.database.dao;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import com.example.vinhosdocampoapp.data.database.entity.Vinho;

import java.util.List;

@Dao
public interface VinhoDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insert(Vinho vinho);

    @Query("SELECT * FROM vinhos ORDER BY nome ASC")
    LiveData<List<Vinho>> getAllVinhos();

    @Query("SELECT * FROM vinhos WHERE tipo = :tipo ORDER BY nome ASC")
    LiveData<List<Vinho>> getVinhosPorTipo(String tipo);
}